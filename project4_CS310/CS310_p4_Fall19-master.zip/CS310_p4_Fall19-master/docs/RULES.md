## Rules
[back](README.md)

### You must:
1. Fill out readme.txt (**NOT README.md**, which is the documentation for this website) with your information (goes in your user folder)
2. Have a style (indentation, good variable names, etc.) -- you must pass the style checker!
3. Comment your code well in JavaDoc style (no need to overdo it, just do it well) -- you must pass the comments checker!
4. Have code that compiles with the command: `javac -cp .;310libs.jar *.java` (Windows) or `javac -cp .:310libs.jar *.java` (Linux/MacOS) in your user directory

### You may:
1. Add any additional private helper methods or instance variables to existing classes.
2. Add any additional classes you have written entirely yourself (such as simple data structures from previous projects). You may not add any imports not allowed on the previous projects to those files.
3. [In ArrayOfListsOfPairs **ONLY**] add any additional public methods and variables (but the existing ones still need to work).
4. Use any of the Java Collections Framework classes in `java.util` already imported for you. You may not add any imports that do not already exist.

### You may not:
1. Make your program part of a package.
2. Import any additional libraries/packages.
3. Alter any method signatures defined in the template code. Note: "throws" is part of the method signature in Java, don’t add/remove these.
4. Add `@SuppressWarnings` to any methods unless they are private helper methods for use with a method we provided which already has an `@SuppressWarnings` on it.
5. Alter any fully provided classes (specifically `SimGUI`) or methods that are complete and marked in a "DO NOT EDIT" section.
6. Use any code from the internet (including the JUNG libary) which was not provided to you in 310libs.jar.

## Submission Instructions:
- Use the cloud or some other server to backup your code!
- Remove all test files, jar files, class files, etc.
- You should just submit your java files and your readme.txt
- Zip your user folder (not just the files) and name the zip `section-username-p4.zip` (no other type of archive) where `username` is your username.
- Submit to blackboard.
