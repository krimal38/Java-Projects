import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class AttachedList<T> implements List<T> {
	//for more information on these methods
	//read the documentation of the list interface
	//here: https://docs.oracle.com/javase/8/docs/api/java/util/List.html
	//keep in mind that we are doing a _linked_ list
	//but the documentation is for general lists (like array lists)
	
	//NOTE: the documentation above is not optional, it tells you things
	//like what exceptions to throw
	
	private static class Node<T> {
		//you may NOT change these instance variables and/or
		//add any additional instance variables here
		//(so you may not doubly link your list)
		T value;
		Node<T> next;
		
		//you may add more methods here... and they may be public!
		//note: a constructor _is_ a method (just a special type of method)
		//note: you don't have to add anything if you don't want
		//      this will work as-is
	}
	
	
	private Node<T> head = null;
	//You _MUST_ use head defined above, we will be "breaking into"
	//your class for testing and we'll be using this "head" variable
	//as part of the tests. If you rename or change it, you will
	//not pass the unit tests.
	
	//Note: if you're interested on what "breaking in" means, it means
	//we'll be using reflection to access your private instance variables.
	//Interested? See: https://docs.oracle.com/javase/tutorial/reflect/index.html
	
	
	//you may add more private methods and instance variables here if you want
	//you may add additional private helper functions as well
	//no new protected or public variables or methods
	
	public AttachedList() {
		//initialize anything you want here...
	}
	
	@Override
	public int size() {
		throw new UnsupportedOperationException("Not supported yet. Replace this line with your implementation.");
		//O(1)
	}

	@Override
	public boolean isEmpty() {
		throw new UnsupportedOperationException("Not supported yet. Replace this line with your implementation.");
		//O(1)
	}

	@Override
	public int indexOf(Object o) {
		throw new UnsupportedOperationException("Not supported yet. Replace this line with your implementation.");
		//O(n)
		//yes, nulls are allowed to be searched for
	}

	@Override
	public boolean contains(Object o) {
		throw new UnsupportedOperationException("Not supported yet. Replace this line with your implementation.");
		//O(n)
		//yes, nulls are allowed to be searched for
	}

	@Override
	public boolean add(T e) {
		throw new UnsupportedOperationException("Not supported yet. Replace this line with your implementation.");
		//this should append to the end of the list
		//O(1) <-- not a typo... think about it!
		//yes, nulls are allowed to be added
	}

	@Override
	public void add(int index, T element) {
		throw new UnsupportedOperationException("Not supported yet. Replace this line with your implementation.");
		//O(n)
		//yes, nulls are allowed to be added
	}
	
	@Override
	public T remove(int index) {
		throw new UnsupportedOperationException("Not supported yet. Replace this line with your implementation.");
		//O(n)
	}

	@Override
	public boolean remove(Object o) {
		throw new UnsupportedOperationException("Not supported yet. Replace this line with your implementation.");
		//O(n)
		//yes, nulls are allowed to removed
	}

	@Override
	public void clear() {
		throw new UnsupportedOperationException("Not supported yet. Replace this line with your implementation.");
		//O(1) <-- not a typo... think about it!
	}

	@Override
	public T get(int index) {
		throw new UnsupportedOperationException("Not supported yet. Replace this line with your implementation.");
		//O(n)
	}

	@Override
	public T set(int index, T element) {
		throw new UnsupportedOperationException("Not supported yet. Replace this line with your implementation.");
		//O(n)
	}

	public AttachedList<T> slice(int fromIndex, int toIndex) {
		throw new UnsupportedOperationException("Not supported yet. Replace this line with your implementation.");
		
		//removes a "slice" from fromIndex to toIndex (inclusive)
		//return the slice as a new AttachedList
		//throws IndexOutOfBoundsException if fromIndex _or_ toIndex is invalid
		
		//O(n)
	}

	public AttachedList<T> reverseCopy() {
		throw new UnsupportedOperationException("Not supported yet. Replace this line with your implementation.");
		
		//returns a copy of the list with the elements reversed
		//does not alter the original list
		
		//O(n)
	}
	
	public static <E> AttachedList<E> flatten(AttachedList<AttachedList<E>> packedList) {
		//given a 2D list of lists (packedList), "flatten" the list into 1D
		//Example 1: [[1,2,3],[4,5],[6]] becomes [1,2,3,4,5,6]
		//Example 2: [[null],[1,3],[5],[6]] becomes [null,1,3,5,6]
		//IMPORTANT: the above examples are _lists NOT arrays_
	}
	
	public static <E> AttachedList<AttachedList<E>> pack(AttachedList<E> flatList) {
		//given a 1D (flatList), "pack" sequential items together
		//to form a 2D list of values
		
		//Example 1: [1,1,2,3,3] becomes [[1,1],[2],[3,3]]
		//Example 1: [1,1,2,1,1,2,2,2,2] becomes [[1,1],[2],[1,1],[2,2,2,2]]
		//Example 3: [1,2,3,4,5] becomes [[1],[2],[3],[4],[5]]
		//IMPORTANT: the above examples are _lists NOT arrays_
		
		//promise: we will never test this with nulls in the flatList
		//though there's no harm in coding it to work with nulls
	}

	@Override
	public Iterator<T> iterator() {
		//this method is outlined for you... just fill out next() and hasNext()
		//NO ADDITIONAL ANYTHING (METHODS, VARIABLES, ETC.) INSIDE THE ANONYMOUS CLASS
		//You may NOT override remove() or any other iterator methods
		return new Iterator<T>() {
			//starts at the head
			private Node<T> current = head;

			@Override
			public boolean hasNext() {
				throw new UnsupportedOperationException("Not supported yet. Replace this line with your implementation.");
				//O(1)
			}

			@Override
			public T next() {
				throw new UnsupportedOperationException("Not supported yet. Replace this line with your implementation.");
				//O(1)
			}
		};
	}
	
	// --------------------------------------------------------
	// testing code goes here... edit this as much as you want!
	// --------------------------------------------------------
	public String toString() {
		//you may edit this to make string representations of your
		//list for testing
		return super.toString();
	}
	
	public static void main(String[] args) {
		
	}
	
	// --------------------------------------------------------
	// DO NOT EDIT ANYTHING BELOW THIS LINE (except to add JavaDocs)
	// --------------------------------------------------------
	
	@Override
	public Object[] toArray() {
		Object[] items = new Object[this.size()];
		int i = 0;
		for(T val : this) {
			items[i++] = val;
		}
		return items;
	}

	@Override
	@SuppressWarnings("unchecked")
	public <T> T[] toArray(T[] a) {
		return (T[]) this.toArray();
	}

	@Override public boolean containsAll(Collection<?> c) { throw new UnsupportedOperationException("Not supported."); }
	@Override public boolean addAll(Collection<? extends T> c) { throw new UnsupportedOperationException("Not supported."); }
	@Override public boolean addAll(int index, Collection<? extends T> c) { throw new UnsupportedOperationException("Not supported."); }
	@Override public boolean removeAll(Collection<?> c) { throw new UnsupportedOperationException("Not supported."); }
	@Override public boolean retainAll(Collection<?> c) { throw new UnsupportedOperationException("Not supported."); }
	@Override public int lastIndexOf(Object o) { throw new UnsupportedOperationException("Not supported."); }
	@Override public ListIterator<T> listIterator() { throw new UnsupportedOperationException("Not supported."); }
	@Override public ListIterator<T> listIterator(int index) { throw new UnsupportedOperationException("Not supported."); }
	@Override public List<T> subList(int fromIndex, int toIndex) { throw new UnsupportedOperationException("Not supported."); }
}