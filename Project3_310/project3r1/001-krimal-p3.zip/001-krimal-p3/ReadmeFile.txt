Kshitiz Rimal
krimal
G01161557
Lecture: 002
