import java.util.ArrayList;  // Use ArrayList, if you must, ONLY LOCALLY

public class Strie{
	// Do NOT remove any method even if you are not implementing it
	
	private StrieNode root;  // the root of a strie

	public Strie(){
		// constructor
		// initialize anything that needs initialization
		
	}

	public static boolean isEmptyStrie(Strie myStrie){
		// returns true if myStrie is empty
		// O(1)
		
		return false;
	}

	public void insert(String word){
		// inserts word into Strie. 
		// word must contain characters between 'a' and 'z'. If not, throw RuntimeException with message "Invalid character entered. Characters must be between 'a' and 'z' "
		// O(n), where n is the number of characters in word
		
	}

	public boolean contains(String word){
		// returns true if Strie contains word
		// word must contain characters between 'a' and 'z', otherwise, returns false.
		// O(n), where n is the number of characters in word
		
		return false;
	}

	public boolean remove(String word){
		// removes word from Strie
		// word must contain characters between 'a' and 'z', otherwise, returns false.
		// consider using recursion, might be helpful for this method
		
		return false;
	}


	public static String levelOrderTraversal(Strie myStrie){
		// Do a Breadth First Traversal of myStrie
		// return the string built during traversal
		
		return null;
	}

	public static String[] getStrieWords(Strie myStrie){
		// returns all words currently stored in myStrie
		// if myStrie is empty, throw RuntimeException with message "Strie is empty"
		// returns words in alphabetical order
		// Example: myStrie contains: bat, cat, bar, barn. Returns: [bar, barn, bat, cat] 
		// recursion might be helpful for this method
		
		return null;
	}

	public static String[] getAllSuffixes(Strie myStrie, String query){
		// returns from myStrie all words with prefix query
		// query must contain characters between 'a' and 'z'
		// otherwise, throw RuntimeException with message "Invalid character entered. Characters must be between 'a' and 'z' " 
		// if no word is found in myStrie for the given prefix query, throw RuntimeException with message "No suffixes found with the given prefix"
		// example: Your Strie stores these words: tea, ted, teen, teeth, team, med
		//           query: tee
		//           returns: teen, teeth
		// returns words in alphabetical order
		
		return null;
	}

	
	public static String getLongestPrefix(Strie myStrie, String query){
		// Given query, returns the longest prefix stored in myStrie 
		// If no prefix can be found, throw RuntimeException with message "No prefix found!"
		// query must contain characters between 'a' and 'z'
		// otherwise, throw RuntimeException with message "Invalid character entered. Characters must be between 'a' and 'z' " 
		// O(n), where n is the number of characters in query
		// Example: Your Strie stores these words: ban, band, banned, banana, can 
		//          query: bandana
		//          returns: band
		
		return null;
	}

	public static String[] getClosestMatch(Strie myStrie, String query){
		// Returns the closest match(es) found in myStrie for the given query 
		// query must contain characters between 'a' and 'z'
		// otherwise, throw RuntimeException with message "Invalid character entered. Characters must be between 'a' and 'z' " 
		// closest match rules: return the word(s) with the smallest distance between word_in_myStrie and query
		// 1. length of query == length of word_in_myStrie
		//    distance = charcter mismatches between query and word_in_myStrie at each position (distance(barn, bird) = 2)
		// 2. length of query != length of word_in_myStrie
		//    find substrings by moving a sliding window of length = smaller(query, word_in_myStrie) 
		//    distance_substring = absolute_length_difference(word_in_myStrie, query) + mismatch of characters at each position of substring and query
		//    distance = smallest distance_substring
		//    example: query: bann, word_in_myStrie = banned. absolute_length_difference(word_in_myStrie, query) = 2
		//             substrings: bann, anne, nned
		//             distance_substring(bann, bann) = 2, distance_substring(bann, anne) = 5, distance_substring(bann, nned) = 6
		//             distance(bann, banned) = 2
		// return the words with minimum distance
		// if the minumim cost of the closest match >= length of query, throw RuntimeException with message "Can't suggest a word! No close word found!"
		// Example: your Strie stores these words: barn, ban, banana, banned, bird
		//          query: bann 
		//          returns: ban, barn 
		// returns words in alphabetical order
		
		return null;
	}

	// --------------------------------------------------------
	// example testing code... edit this as much as you want!
	// --------------------------------------------------------
	public static void main(String[] args){
		Strie myStrie = new Strie();
	
		if(isEmptyStrie(myStrie) && myStrie.root.isEmptyNode())
			System.out.println("Yay 1");

		myStrie.insert("a");
		StrieNode[] children = myStrie.root.getAllChildren();
		if(!isEmptyStrie(myStrie) && children[0].isEmptyNode() && children[0].isEnd() && myStrie.root.containsChar('a'))
			System.out.println("Yay 2");

		myStrie.insert("bat");
		myStrie.insert("bar");
		myStrie.insert("barn");
		myStrie.insert("cat");

		if(myStrie.contains("cat"))
			System.out.println("Yay 3");

		String res = Strie.levelOrderTraversal(myStrie).trim();
		String actualOut = "a b c a a r t t n";
		if(res.equals(actualOut))
			System.out.println("Yay 4");

		String[] yourWords = Strie.getStrieWords(myStrie);
		String[] allWords = {"a", "bar", "barn", "bat", "cat"};
		int allMatches = 1;
		for(int i = 0; i < yourWords.length; i++){
			if(!yourWords[i].equals(allWords[i]))
				allMatches = 0;
		}	
		if(allMatches == 1)
			System.out.println("Yay 5");

		if(myStrie.remove("cat") && !myStrie.contains("cat"))
			System.out.println("Yay 6");

	}

}
